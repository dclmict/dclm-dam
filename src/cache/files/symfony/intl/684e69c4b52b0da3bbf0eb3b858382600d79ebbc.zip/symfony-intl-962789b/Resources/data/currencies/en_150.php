<?php

return [
    'Names' => [
        'EUR' => [
            0 => '€',
            1 => 'Euro',
        ],
    ],
];

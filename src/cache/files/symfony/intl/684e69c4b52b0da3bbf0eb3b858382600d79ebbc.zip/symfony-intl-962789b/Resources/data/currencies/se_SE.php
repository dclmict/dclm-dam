<?php

return [
    'Names' => [
        'NOK' => [
            0 => 'Nkr',
            1 => 'norgga kruvdno',
        ],
        'SEK' => [
            0 => 'kr',
            1 => 'ruoŧŧa kruvdno',
        ],
    ],
];

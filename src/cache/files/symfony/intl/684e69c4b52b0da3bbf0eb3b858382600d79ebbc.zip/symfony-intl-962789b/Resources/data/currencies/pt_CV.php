<?php

return [
    'Names' => [
        'CVE' => [
            0 => '​',
            1 => 'escudo cabo-verdiano',
        ],
        'PTE' => [
            0 => 'PTE',
            1 => 'escudo português',
        ],
    ],
];

<?php

return [
    'Names' => [
        'CRC' => [
            0 => 'CRC',
            1 => 'Costa Rican colon',
        ],
        'ISK' => [
            0 => 'ISK',
            1 => 'Icelandic krona',
        ],
        'NIO' => [
            0 => 'NIO',
            1 => 'Nicaraguan cordoba',
        ],
        'RUB' => [
            0 => 'RUB',
            1 => 'Russian ruble',
        ],
        'STN' => [
            0 => 'STN',
            1 => 'Sao Tome & Principe Dobra',
        ],
        'VES' => [
            0 => 'VES',
            1 => 'Venezuelan bolivar',
        ],
    ],
];

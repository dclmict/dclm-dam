<?php

return [
    'Names' => [
        'TOP' => [
            0 => 'T$',
            1 => 'Tongan Paʻanga',
        ],
    ],
];

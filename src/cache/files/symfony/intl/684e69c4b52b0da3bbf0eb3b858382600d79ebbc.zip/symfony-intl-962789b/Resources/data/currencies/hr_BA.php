<?php

return [
    'Names' => [
        'BAM' => [
            0 => 'KM',
            1 => 'konvertibilna marka',
        ],
    ],
];

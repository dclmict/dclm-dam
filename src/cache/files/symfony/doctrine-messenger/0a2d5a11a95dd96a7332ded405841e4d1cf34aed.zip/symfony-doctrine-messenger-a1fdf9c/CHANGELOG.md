CHANGELOG
=========

5.1.0
-----

 * Introduced the Doctrine bridge.
 * Added support for PostgreSQL `LISTEN`/`NOTIFY`.

#!/bin/bash

set -eu -o xtrace

cp .github/ci/files/.env .
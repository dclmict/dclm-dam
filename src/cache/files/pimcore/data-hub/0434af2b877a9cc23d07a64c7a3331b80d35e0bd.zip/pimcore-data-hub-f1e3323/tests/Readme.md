# Running and creating tests

Tests can be executed locally in a separate docker-compose. This docker-compose also sets up database accordingly. 

To run, just execute [/bin/init-tests.sh](./bin/init-tests.sh) script and follow instructions there.

Additional tests may be added following codeception best practises. 